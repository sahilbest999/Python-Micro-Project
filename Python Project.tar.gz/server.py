from flask import Flask, request
from flask_restful import Resource, Api
import os

app = Flask(__name__)
api = Api(app)


class Signup(Resource):
    def post(self):
        print(request.form['data'])
        return {'success':True}

api.add_resource(Signup,'/signup')

if __name__== '__main__':
    app.run(debug=True,port=8080)